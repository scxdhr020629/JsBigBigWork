<template>
	<div class="search">
		<router-view></router-view>
	</div>
</template>

