<template>
    <header>
		<div>
			<i class='iconfont icon-fanhui' @click="goBack"></i>
		</div>
		<div>
			<slot>
				<span>登录</span>
			</slot>
		</div>
		<div>
			<i class="iconfont icon-kefu"></i>
		</div>
	</header>
</template>


<script>
export default {
    data(){
        return{}
    },
  methods:{
    goBack(){
        this.$router.back()
    }
  }
}
</script>

<style lang="less" scoped>
header{
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 100%;
	height: 1.173333rem;
	color:#fff;
	background-color: #b0352f;
	span{
		font-size:0.6rem;
        line-height: 1.173333rem;
	}
	i{
		padding:0 0.4rem;
		font-size:0.7rem;
         line-height: 1.173333rem;
	}
}
</style>