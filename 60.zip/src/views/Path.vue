<template>
    <div class='path'>
        <router-view></router-view>
    </div>
</template>

<script>
</script>

<style>
</style>
