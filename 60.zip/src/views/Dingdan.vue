<template>
    <div class='Dingdan'>
        <router-view></router-view>
    </div>
</template>

<script>
</script>

<style>
</style>
